function Titulo() {
    return <h1>Vengo de la App Titulo</h1>;    
}

export default Titulo;