/**import charmander from './components/images/charmander.jpg'
import evee from './components/images/evee.png'
import pikachu from './components/images/pikachu.jfif'
import squirtle from './components/images/squiertle.png'
import bulbasur from './components/images/bulbasur.png'

export default{
    "img1": charmander,
    "img2": pikachu,
    "img3": evee,
    "img4": squirtle,
    "img5": bulbasur

} */

