import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Pokemon } from './pokemon.entity';
import { PokemonService } from './pokemon.service';
import { PokemonController } from './pokemon.controller';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: 'pokemon.db',
      entities: [Pokemon],
      synchronize: true,   // solo en dev
    }),
    TypeOrmModule.forFeature([Pokemon]),
  ],
  controllers: [PokemonController],
  providers: [PokemonService],
})
export class AppModule {}
